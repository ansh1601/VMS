const express = require("express");
const bodyParser = require("body-parser").json();
const elasticsearch = require("elasticsearch");
const app = express();
app.use(bodyParser);

// if the dependencies are not installed just do npm install express elasticsearch body-parser

app.listen(process.env.PORT || 3000, () => {
    console.log("connected")
});

// connection with elastic search 

const esClient = elasticsearch.Client({
    host: "localhost:9200",
});

// check elasticsearch health first

esClient.cluster.health({},function(err,resp,status) {  
  console.log("-- Client Health --",resp);
});

//  Post to Vendor using body ... mention the details of body in POSTman also

app.post("/vendor", (req, res) => {
    esClient.index({
        index: 'vendor',
        body: {
            "_id": req.body._id,
            "name": req.body.name,
            "ratings": req.body.ratings,
        }
    })
    .then(response => {
        return res.json({"message": "Indexing successful"})
    })
    .catch(err => {
         return res.status(500).json({"message": "Error"})
    })
});

// GET list of vendors by name
// to get vendor in params enter key as text and value as the name of doc that you want to search

app.get("/vendor", (req, res) => {
    const searchText = req.query.text
    esClient.search({
        index: "vendor",
        body: {
            query: {
                match: {"name": searchText.trim()}
            }
        }
    })
    .then(response => {
        return res.json(response)
    })
    .catch(err => {
        return res.status(500).json({"message": "Error"})
    })
});

// GET list of all vendors available

app.get("/", (req, res)=>{
    let query = {
      index: "vendor"
    }
    if (req.query.vendor) query.q =  `*${req.query.vendor}*`;
    esClient.search(query)
    .then(resp=>{
      return res.status(200).json({
        vendor: resp.hits.hits
      });
    })
    .catch(err=>{
      console.log(err);
      return res.status(500).json({
        msg: 'Error',
        err
      });
    });
  });

  // Update Vendor by name using put method

  app.put("/vendor/:name", bodyParser, (req, res)=>{
    esClient.update({
      index: "vendor",
      name: req.params.name,
      body: {
        doc: req.body
      }
    })
    .then(resp=>{
      return res.status(200).json({
        msg: 'vendor updated'
      });
    })
    .catch(err=>{
      console.log(err)
      return res.status(500).json({
        msg: 'Error',
        err
      });
    })
  });



